# `♦️HATSUNE-MIKU-ULTRA💥`

### `🏓DUDAS SOBRE EL BOT?, CONTACTANOS🍁`
<a href="http://wa.me/0050576170388" target="blank"><img src="https://img.shields.io/badge/OFC-Jeffrey_CREADOR-25D366?style=for-the-badge&logo=whatsapp&logoColor=white" />
<a href="http://wa.me/5212411233838" target="blank"><img src="https://img.shields.io/badge/OFC-Jeffreay_CREADOR-25D366?style=for-the-badge&logo=whatsapp&logoColor=white" />


### `⛄GRUPO DE INFORMACIÓN DEL BOT Y ACTUALIZACIONES🧿`

<a href= "https://chat.whatsapp.com/Jhs2WrdiNzY3CML7shPwot" target="blank"><img src="https://img.shields.io/badge/GRUPO_DE_SOPORTE-25D366?style=for-the-badge&logo=whatsapp&logoColor=white" />
</a>
> LOS NUMEROS NO SON BOTS Y EN EL GRUPO NO SE PERMITEN NUMEROS-BOTS

### `—◉ 🤖 BOTS OFICIALES 🤖`

<a href="https://api.whatsapp.com/send/?phone=521241719888&text&type=phone_number&app_absent=0" target="blank"><img src="https://img.shields.io/badge/BOT-OFICIAL.1-25D366?style=for-the-badge&logo=whatsapp&logoColor=white" />

 > NO SPAMEAR COMANDOS

### `🖍 LETRA DEL BOT 🖍`
- PAGINA USADA PARA LA LETRA [Aqui](https://smiley.cool/es/weirdmaker.php)

### `—◉ 💡 EXPERIMENTA CON UNA IA PARA NUEVOS COMANDOS 💡`
- PAGINA [Aqui](https://beta.openai.com/playground)

### `—◉ 🌌 ACTIVAR EN REPLIT 🌌`

[![Run on Repl.it](https://repl.it/badge/github/OFC-YOVANI/HATSUNE-MIKU-ULTRA)](https://repl.it/github/OFC-YOVANI/HATSUNE-MIKU-ULTRA)

### `—◉ 💥 ACTIVAR EN KOYEB 💥`

[![Deploy to Koyeb](https://www.koyeb.com/static/images/deploy/button.svg)](https://app.koyeb.com/deploy?type=git&repository=github.com/OFC-YOVANI/HATSUNE-MIKU&branch=master&name=Hatsunemikubot)

### `—◉ ✨ ACTIVAR EN HEROKU ✨`
[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/OFC-YOVANI/HATSUNE-MIKU-ULTRA)

### `—◉ ⚙️ AJUSTES ⚙️`
- CLONAR EL REPOSITORIO [Aqui](https://github.com/OFC-YOVANI/HATSUNE-MIKU-ULTRA/fork)
- CAMBIAR NÚMERO DEL OWNER [Aqui](https://github.com/OFC-YOVANI/HATSUNE-MIKU-ULTRA/blob/master/config.js)

### `—◉ 👾 ACTIVAR EN TERMUX 👾
PRIMERA OPCIÓN `
- ESCRIBE LOS SIGUIENTES COMANDOS UNO POR UNO:
```bash
termux-setup-storage
```

```bash
pkg update -y && pkg upgrade -y && pkg install -y bash && pkg install -y wget && pkg install yarn
```

```bash
wget -O - https://raw.githubusercontent.com/OFC-YOVANI/HATSUNE-MIKU-ULTRA/master/install.sh | bash
```


### `—◉ 👾 ACTIVAR EN TERMUX 👾
SEGUNDA OPCIÓN ` 
- ESCRIBE LOS SIGUIENTES COMANDOS UNO POR UNO:
```bash
cd && termux-setup-storage
```

```bash
apt-get update -y && apt-get upgrade -y
```

```bash
pkg install -y git nodejs ffmpeg imagemagick && pkg install yarn
```

```bash
git clone https://github.com/OFC-YOVANI/HATSUNE-MIKU-ULTRA.git && cd HATSUNE-MIKU-ULTRA
```

```bash
yarn
```

```bash
npm install
```

```bash
npm update
```

```bash
npm start
```

### `—◉ ✔️ ACTIVAR EN CASO DE DETENERSE EN TERMUX ✔️`

### `ESCRIBE LOS SIGUIENTES COMANDOS UNO POR UNO:`

```bash
> cd HATSUNE-MIKU-ULTRA
```

```bash
> npm start
```

### `—◉ 👽 OBTENER OTRO CODIGO QR EN TERMUX 👽`
 DETENER EL BOT DANDO CLICK EN EL SIMBOLO CTROL EN TERMUX MAS LA LETRA Z EN SU TECLADO MOVIL HASTA QUE SALGA ALGO EN VERDE SIMILAR A HADES-BOT-MD $`

### `ESCRIBE LOS SIGUIENTES COMANDOS UNO POR UNO:`

```bash
> cd HATSUNE-MIKU-ULTRA
```

```bash
> rm -rf Session-activa
```

```bash
> npm start
```

### `—◉ 📝 NOTAS 📝`
- ES POSIBLE QUE EL BOT TENGA ALGUNAS FALLAS, SE IRAN SOLUCIONANDO CONFORME SE VAYAN DETECTANDO
- SI VAS A EDITAR POR COMPLETO DEJA LOS CREDITOS DEL BOT 
- EL BOT ES COMPARTIBLE CON WHATSAPP NORMAL O BUSINESS
- ATENTO A LAS ACTUALIZACIONES QUE SE HAGAN EN ESTE REPOSITORIO
- EL ADD Y EL KICK PUEDEN OCASIONAR QUE EL NUMERO SE VAYA A SOPORTE POR ELLO SE ACTIVA CON #enable restrict 
- HATSUNE-MIKU - TEAM NO SE HACE RESPONSABLE DEL USO, NUMEROS, PRIVACIDAD Y CONTENIDO MANDADO, USADO O GESTIONADO POR USTEDES O EL BOT


## `CREADO POR Jeffrey` 
<a href="https://github.com/OFC-YOVANI"><img src="https://i.imgur.com/JP52fdP.jpg" width="250" height="250" alt="JeffreyI"/></a>
 Goky - By YOVANI` Jeffrey
